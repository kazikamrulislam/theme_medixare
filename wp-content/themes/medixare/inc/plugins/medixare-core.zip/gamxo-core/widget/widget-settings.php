<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

add_action( 'widgets_init', 'gamxo_widgets_init' );
function gamxo_widgets_init() {
	// Register Custom Widgets
	register_widget( 'GamxoTheme_About_Widget' );
	register_widget( 'GamxoTheme_Footer_About_Widget' );
	register_widget( 'GamxoTheme_Address_Widget' );
	register_widget( 'GamxoTheme_Social_Widget' );
	register_widget( 'GamxoTheme_Post_Box' );
	register_widget( 'GamxoTheme_Post_Tab' );
	register_widget( 'GamxoTheme_Feature_Post' );
	register_widget( 'GamxoTheme_Category_Widget' );	
}